insert into UserInfo(Name,Address) values ('Pandi', 'Chennai');
insert into UserInfo(Name,Address) values ('Mr. Foo','NY');
insert into UserInfo(Name,Address) values ('Ms. Bar','Austin');