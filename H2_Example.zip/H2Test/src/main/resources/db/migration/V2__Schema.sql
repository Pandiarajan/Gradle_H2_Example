DROP ALL OBJECTS;
SET COLLATION ENGLISH STRENGTH PRIMARY;

CREATE TABLE UserInfo(
	Id int Identity(1,1),
	Name varchar(30) NOT NULL,
	Address varchar(254) NULL,
 CONSTRAINT pkUserInfo PRIMARY KEY
(
	Id ASC
)
);